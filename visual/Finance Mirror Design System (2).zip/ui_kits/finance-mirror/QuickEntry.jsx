// Finance Mirror UI Kit — Quick Entry modal (natural-language parser "32 ifood almoço").

const ALIASES = {
  ifood: { merchant: 'iFood', cat: 'Alimentação', icon: 'utensils' },
  uber: { merchant: 'Uber', cat: 'Transporte', icon: 'car' },
  netflix: { merchant: 'Netflix', cat: 'Assinaturas', icon: 'tv' },
  mercado: { merchant: 'Supermercado', cat: 'Alimentação', icon: 'shopping-cart' },
  posto: { merchant: 'Posto', cat: 'Transporte', icon: 'fuel' },
};

function parseEntry(text) {
  const amountMatch = text.match(/\d+[.,]?\d*/);
  const amount = amountMatch ? parseFloat(amountMatch[0].replace(',', '.')) : 0;
  const words = text.toLowerCase().replace(amountMatch ? amountMatch[0] : '', '').trim().split(/\s+/).filter(Boolean);
  let alias = null, aliasWord = null;
  for (const w of words) { if (ALIASES[w]) { alias = ALIASES[w]; aliasWord = w; break; } }
  const desc = words.filter((w) => w !== aliasWord).join(' ');
  return {
    amount,
    merchant: alias ? alias.merchant : (words[0] ? words[0][0].toUpperCase() + words[0].slice(1) : '—'),
    cat: alias ? alias.cat : 'Outros',
    icon: alias ? alias.icon : 'receipt',
    desc: desc || (alias ? '' : ''),
  };
}

function QuickEntry({ onClose, onAdd }) {
  useLucide();
  const [text, setText] = React.useState('32 ifood almoço');
  const parsed = parseEntry(text);
  const inputRef = React.useRef(null);
  React.useEffect(() => { if (inputRef.current) inputRef.current.focus(); }, []);
  const submit = () => {
    if (parsed.amount <= 0) return;
    onAdd({ id: Date.now(), name: parsed.merchant, cat: parsed.cat, date: 'Hoje', amount: -parsed.amount, icon: parsed.icon, tag: null });
    onClose();
  };
  return React.createElement('div', {
    onClick: onClose,
    style: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'flex-start', justifyContent: 'center', paddingTop: '14vh', zIndex: 50, animation: 'fmFade 200ms ease-out' },
  },
    React.createElement('div', {
      onClick: (e) => e.stopPropagation(),
      style: { width: '100%', maxWidth: 480, background: 'var(--card-2)', border: '1px solid var(--border)', borderRadius: 'var(--r-lg)', boxShadow: 'var(--shadow-lg)', overflow: 'hidden' },
    },
      React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 10, padding: '16px 18px', borderBottom: '1px solid var(--border)' } },
        React.createElement(Icon, { name: 'zap', size: 18, color: 'var(--rosa-rubi)' }),
        React.createElement('input', {
          ref: inputRef, value: text, onChange: (e) => setText(e.target.value),
          onKeyDown: (e) => { if (e.key === 'Enter') submit(); },
          placeholder: 'ex: 32 ifood almoço',
          style: { flex: 1, background: 'transparent', border: 'none', outline: 'none', color: 'var(--fg1)', fontSize: 16, fontFamily: 'var(--font-sans)' },
        }),
        React.createElement('kbd', { style: { fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--fg3)', background: 'var(--bg-2)', padding: '2px 6px', borderRadius: 4, border: '1px solid var(--border)' } }, '↵')),
      // Preview
      React.createElement('div', { style: { padding: 18 } },
        React.createElement('div', { style: { fontSize: 11, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--fg3)', marginBottom: 12 } }, 'Pré-visualização'),
        React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 12 } },
          React.createElement('div', { style: { width: 42, height: 42, borderRadius: 11, background: 'var(--bg-2)', display: 'flex', alignItems: 'center', justifyContent: 'center' } },
            React.createElement(Icon, { name: parsed.icon, size: 18, color: 'var(--rosa-rubi)' })),
          React.createElement('div', { style: { flex: 1 } },
            React.createElement('div', { style: { fontSize: 15, color: 'var(--fg1)', fontWeight: 500 } }, parsed.merchant),
            React.createElement('div', { style: { fontSize: 12, color: 'var(--fg3)', marginTop: 2, display: 'flex', alignItems: 'center', gap: 6 } },
              parsed.desc && React.createElement('span', null, parsed.desc),
              React.createElement(Badge, { tone: 'wine' }, parsed.cat))),
          React.createElement(Value, { amount: parsed.amount, type: 'expense', size: 18, prefixSign: true }))),
      React.createElement('div', { style: { display: 'flex', justifyContent: 'flex-end', gap: 10, padding: '0 18px 18px' } },
        React.createElement(Button, { variant: 'ghost', size: 'sm', onClick: onClose }, 'Cancelar'),
        React.createElement(Button, { variant: 'primary', size: 'sm', icon: 'check', onClick: submit }, 'Lançar'))));
}

Object.assign(window, { QuickEntry, parseEntry });
