// Finance Mirror UI Kit — Login screen (matches mockup_login).

function LoginScreen({ onLogin }) {
  useLucide();
  const [email, setEmail] = React.useState('joao@email.com');
  const [pwd, setPwd] = React.useState('••••••••');
  const [focus, setFocus] = React.useState(null);
  const field = (key, label, value, set, type) =>
    React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: 6 } },
      React.createElement('label', { style: { fontSize: 13, color: 'var(--fg2)' } }, label),
      React.createElement('input', {
        type, value, onChange: (e) => set(e.target.value),
        onFocus: () => setFocus(key), onBlur: () => setFocus(null),
        style: {
          background: 'var(--bg-2)', border: `1px solid ${focus === key ? 'var(--vinho-profundo)' : 'var(--border)'}`,
          boxShadow: focus === key ? '0 0 0 3px rgba(123,30,58,0.25)' : 'none',
          borderRadius: 'var(--r-md)', padding: '12px 14px', color: 'var(--fg1)', fontSize: 14,
          fontFamily: 'var(--font-sans)', outline: 'none', transition: 'all 150ms',
        },
      }));
  return React.createElement('div', {
    style: { minHeight: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, background: 'radial-gradient(circle at 50% 0%, #2B141C 0%, #1A1416 55%)' },
  },
    React.createElement('div', { style: { width: '100%', maxWidth: 360, display: 'flex', flexDirection: 'column', alignItems: 'center' } },
      React.createElement('img', { src: '../../assets/logo.png', alt: 'Finance Mirror', style: { width: 92, marginBottom: 16 } }),
      React.createElement('div', { style: { fontSize: 26, fontWeight: 700, color: 'var(--fg1)', letterSpacing: '-0.01em' } },
        'finance', React.createElement('span', { style: { color: 'var(--rosa-rubi)' } }, '-'), 'mirror'),
      React.createElement('div', { style: { fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase', color: 'var(--fg3)', marginTop: 6, marginBottom: 30 } },
        'Seu ', React.createElement('span', { style: { color: 'var(--rosa-rubi)', fontWeight: 600 } }, 'Reflexo'), ' Financeiro.'),
      React.createElement('form', {
        onSubmit: (e) => { e.preventDefault(); onLogin(); },
        style: { width: '100%', display: 'flex', flexDirection: 'column', gap: 16 },
      },
        field('email', 'E-mail', email, setEmail, 'email'),
        field('pwd', 'Senha', pwd, setPwd, 'password'),
        React.createElement(Button, { variant: 'primary', style: { width: '100%', justifyContent: 'center', marginTop: 4 } }, 'Entrar')),
      React.createElement('button', {
        onClick: onLogin,
        style: { marginTop: 18, background: 'none', border: 'none', color: 'var(--fg3)', fontSize: 13, cursor: 'pointer', fontFamily: 'var(--font-sans)' },
      }, 'Esqueceu sua senha?')));
}

Object.assign(window, { LoginScreen });
