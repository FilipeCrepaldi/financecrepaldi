// Finance Mirror UI Kit — Dashboard (Resumo). Matches the dark mockup.

function StatCard({ label, value, type, icon, iconColor, delta, deltaType, spark, sparkColor, progress }) {
  return React.createElement(Card, { pad: 16 },
    React.createElement('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 } },
      React.createElement('span', { style: { fontSize: 13, color: 'var(--fg3)' } }, label),
      React.createElement(Icon, { name: icon, size: 16, color: iconColor || 'var(--fg3)' })),
    React.createElement('div', { style: { display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 8 } },
      React.createElement(Value, { amount: value, type, size: 22 }),
      spark && React.createElement(Sparkline, { data: spark, color: sparkColor, width: 84, height: 30 })),
    delta && React.createElement('div', { style: { fontSize: 11, marginTop: 8, color: deltaType === 'income' ? 'var(--receita)' : 'var(--fg3)' } }, delta),
    progress != null && React.createElement('div', { style: { marginTop: 10, height: 6, background: 'var(--bg-2)', borderRadius: 999, overflow: 'hidden' } },
      React.createElement('div', { style: { height: '100%', width: `${progress}%`, background: 'linear-gradient(90deg,#7B1E3A,#BE4B6B)', borderRadius: 999 } })));
}

function TxnRow({ t }) {
  return React.createElement('div', {
    style: { display: 'flex', alignItems: 'center', gap: 12, padding: '10px 8px', borderRadius: 'var(--r-md)', transition: 'background 150ms' },
    onMouseEnter: (e) => (e.currentTarget.style.background = 'var(--card-2)'),
    onMouseLeave: (e) => (e.currentTarget.style.background = 'transparent'),
  },
    React.createElement('div', { style: { width: 36, height: 36, borderRadius: 10, background: 'var(--bg-2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 } },
      React.createElement(Icon, { name: t.icon, size: 16, color: t.amount >= 0 ? 'var(--receita)' : 'var(--rosa-rubi)' })),
    React.createElement('div', { style: { flex: 1, minWidth: 0 } },
      React.createElement('div', { style: { fontSize: 14, color: 'var(--fg1)', fontWeight: 500 } }, t.name),
      React.createElement('div', { style: { fontSize: 12, color: 'var(--fg3)' } }, t.cat + ' · ' + t.date)),
    React.createElement(Value, { amount: t.amount, type: t.amount >= 0 ? 'income' : 'expense', size: 14, prefixSign: true }));
}

function Dashboard({ transactions }) {
  useLucide();
  const recent = transactions.slice(0, 4);
  const section = (style) => ({ display: 'flex', flexDirection: 'column', ...style });
  const h2 = { fontSize: 16, fontWeight: 600, color: 'var(--fg1)' };
  const seeAll = React.createElement('button', { style: { background: 'none', border: 'none', color: 'var(--rosa-rubi)', fontSize: 13, cursor: 'pointer', fontFamily: 'var(--font-sans)' } }, 'Ver todas');

  return React.createElement('div', { style: { padding: 28, display: 'flex', flexDirection: 'column', gap: 18 } },
    // Stat cards
    React.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 } },
      React.createElement(StatCard, { label: 'Saldo atual', value: 12340, icon: 'wallet', delta: '+ 8,5% vs. Abril', deltaType: 'income', spark: [8, 9, 8.5, 10, 11, 12.34], sparkColor: '#22C55E' }),
      React.createElement(StatCard, { label: 'Receitas', value: 18750, type: 'income', icon: 'trending-up', iconColor: 'var(--receita)', spark: [14, 16, 15, 17, 18.75], sparkColor: '#22C55E' }),
      React.createElement(StatCard, { label: 'Despesas', value: 6410, type: 'expense', icon: 'trending-down', iconColor: 'var(--despesa)', spark: [9, 11, 13, 8, 6.41], sparkColor: '#DC4C64' }),
      React.createElement(MetaCard)),
    // Charts row
    React.createElement('div', { style: { display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 } },
      React.createElement(Card, null,
        React.createElement('div', { style: { ...section(), gap: 16 } },
          React.createElement('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between' } },
            React.createElement('span', { style: h2 }, 'Fluxo de caixa'),
            React.createElement('div', { style: { display: 'flex', gap: 14 } },
              legendDot('var(--receita)', 'Receitas'), legendDot('var(--despesa)', 'Despesas'))),
          React.createElement(BarChart, { data: CASHFLOW }))),
      React.createElement(Card, null,
        React.createElement('span', { style: { ...h2, display: 'block', marginBottom: 14 } }, 'Gastos por categoria'),
        React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 18 } },
          React.createElement(Donut, { data: CATEGORIES, centerLabel: 'R$ 6,4k', centerSub: 'total' }),
          React.createElement('div', { style: { flex: 1, display: 'flex', flexDirection: 'column', gap: 8 } },
            CATEGORIES.map((c) =>
              React.createElement('div', { key: c.name, style: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 } },
                React.createElement('span', { style: { width: 9, height: 9, borderRadius: '50%', background: c.color } }),
                React.createElement('span', { style: { flex: 1, color: 'var(--fg2)' } }, c.name),
                React.createElement('span', { style: { color: 'var(--fg1)', fontFamily: 'var(--font-mono)', fontSize: 12 } }, c.pct + '%'))))))),
    // Bottom row
    React.createElement('div', { style: { display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 } },
      React.createElement(Card, null,
        React.createElement('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 } },
          React.createElement('span', { style: h2 }, 'Transações recentes'), seeAll),
        React.createElement('div', null, recent.map((t) => React.createElement(TxnRow, { key: t.id, t })))),
      React.createElement(Card, null,
        React.createElement('span', { style: { ...h2, display: 'block', marginBottom: 12 } }, 'Contas'),
        React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: 10 } },
          ACCOUNTS.map((a) =>
            React.createElement('div', { key: a.name, style: { display: 'flex', alignItems: 'center', gap: 12 } },
              React.createElement('div', { style: { width: 34, height: 34, borderRadius: 9, background: a.color + '22', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 } },
                React.createElement(Icon, { name: a.icon, size: 15, color: a.color })),
              React.createElement('span', { style: { flex: 1, fontSize: 14, color: 'var(--fg1)' } }, a.name),
              React.createElement(Value, { amount: a.balance, type: a.balance >= 0 ? null : 'expense', size: 14, prefixSign: a.balance < 0 })))))));
}

function MetaCard() {
  return React.createElement(Card, { pad: 16 },
    React.createElement('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 } },
      React.createElement('span', { style: { fontSize: 13, color: 'var(--fg3)' } }, 'Meta mensal'),
      React.createElement(Icon, { name: 'target', size: 16, color: 'var(--dourado-suave)' })),
    React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 12 } },
      React.createElement(Donut, { data: [{ pct: 75, color: '#CDAA5E' }, { pct: 25, color: '#3A2A30' }], size: 70, thickness: 11, centerLabel: '75%' }),
      React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: 3 } },
        React.createElement('span', { style: { fontSize: 11, color: 'var(--fg3)' } }, 'R$ 9.250,00'),
        React.createElement('span', { style: { fontSize: 11, color: 'var(--fg3)' } }, 'de R$ 12.300,00'))));
}

function legendDot(color, label) {
  return React.createElement('span', { style: { display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--fg2)' } },
    React.createElement('span', { style: { width: 8, height: 8, borderRadius: 2, background: color } }), label);
}

Object.assign(window, { Dashboard });
