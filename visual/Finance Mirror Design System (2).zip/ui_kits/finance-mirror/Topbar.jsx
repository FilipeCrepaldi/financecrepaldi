// Finance Mirror UI Kit — Topbar (greeting + month selector + quick entry + bell).

function Topbar({ onQuickEntry }) {
  useLucide();
  const [month, setMonth] = React.useState('Maio 2024');
  const months = ['Março 2024', 'Abril 2024', 'Maio 2024'];
  const [open, setOpen] = React.useState(false);
  return React.createElement('header', {
    style: {
      display: 'flex', alignItems: 'center', gap: 16, padding: '22px 28px',
      borderBottom: '1px solid var(--border)', background: 'rgba(26,20,22,0.7)', backdropFilter: 'blur(8px)',
      position: 'sticky', top: 0, zIndex: 5,
    },
  },
    React.createElement('div', { style: { flex: 1 } },
      React.createElement('h1', { style: { fontSize: 22, fontWeight: 700, color: 'var(--fg1)', letterSpacing: '-0.01em' } }, 'Olá, João! 👋'),
      React.createElement('p', { style: { fontSize: 14, color: 'var(--fg2)', marginTop: 2 } }, 'Aqui está o resumo das suas finanças.')),
    // Month selector
    React.createElement('div', { style: { position: 'relative' } },
      React.createElement('button', {
        onClick: () => setOpen((o) => !o),
        style: { display: 'flex', alignItems: 'center', gap: 8, padding: '9px 14px', borderRadius: 'var(--r-md)', background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--fg1)', fontSize: 14, cursor: 'pointer', fontFamily: 'var(--font-sans)' },
      }, month, React.createElement(Icon, { name: 'chevron-down', size: 15, color: 'var(--fg3)' })),
      open && React.createElement('div', {
        style: { position: 'absolute', top: '110%', right: 0, background: 'var(--card-2)', border: '1px solid var(--border)', borderRadius: 'var(--r-md)', boxShadow: 'var(--shadow-lg)', padding: 6, zIndex: 10, minWidth: 150 },
      }, months.map((m) =>
        React.createElement('button', {
          key: m, onClick: () => { setMonth(m); setOpen(false); },
          style: { display: 'block', width: '100%', textAlign: 'left', padding: '8px 12px', borderRadius: 'var(--r-sm)', background: m === month ? 'rgba(123,30,58,0.22)' : 'none', color: m === month ? 'var(--rosa-rubi)' : 'var(--fg2)', border: 'none', cursor: 'pointer', fontSize: 13, fontFamily: 'var(--font-sans)' },
        }, m)))),
    React.createElement(Button, { variant: 'primary', icon: 'zap', onClick: onQuickEntry }, 'Lançar'),
    React.createElement('button', {
      style: { position: 'relative', width: 40, height: 40, borderRadius: 'var(--r-md)', background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--fg2)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' },
    }, React.createElement(Icon, { name: 'bell', size: 17 }),
      React.createElement('span', { style: { position: 'absolute', top: 8, right: 9, width: 7, height: 7, borderRadius: '50%', background: 'var(--despesa)', border: '1.5px solid var(--card)' } })));
}

Object.assign(window, { Topbar });
