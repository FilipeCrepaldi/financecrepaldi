// Finance Mirror UI Kit — shared primitives, icons, and mock data.
// All components exported to window at the bottom for cross-file use.

const Icon = ({ name, size = 18, color = 'currentColor', strokeWidth = 1.75, style = {} }) =>
  React.createElement('i', {
    'data-lucide': name,
    style: { width: size, height: size, color, strokeWidth, display: 'inline-flex', ...style },
  });

// Re-render lucide icons after React commits
function useLucide(dep) {
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  });
}

const fmt = (n) =>
  'R$ ' + Math.abs(n).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const signed = (n) => (n >= 0 ? '+ ' : '− ') + fmt(n);

// ---------- Primitives ----------
const Card = ({ children, elevated, pad = 18, style = {}, ...rest }) =>
  React.createElement('div', {
    style: {
      background: elevated ? 'var(--card-2)' : 'var(--card)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--r-lg)',
      padding: pad,
      boxShadow: 'var(--shadow-md)',
      ...style,
    },
    ...rest,
  }, children);

const Button = ({ children, variant = 'primary', size = 'md', icon, onClick, style = {} }) => {
  const base = {
    fontFamily: 'var(--font-sans)', fontWeight: 600, border: 'none', cursor: 'pointer',
    borderRadius: 'var(--r-md)', display: 'inline-flex', alignItems: 'center', gap: 8,
    transition: 'all 150ms cubic-bezier(0.16,1,0.3,1)', whiteSpace: 'nowrap',
    fontSize: size === 'sm' ? 13 : 14, padding: size === 'sm' ? '7px 12px' : '10px 18px',
  };
  const variants = {
    primary: { background: 'var(--vinho-profundo)', color: '#fff' },
    gold: { background: 'var(--dourado-suave)', color: 'var(--preto-vinho)', boxShadow: 'var(--shadow-glow-gold)' },
    ghost: { background: 'transparent', color: 'var(--fg2)', border: '1px solid var(--border)' },
    soft: { background: 'rgba(123,30,58,0.18)', color: 'var(--rosa-rubi)' },
  };
  const [hover, setHover] = React.useState(false);
  const hoverStyle = hover
    ? (variant === 'primary' ? { background: 'var(--vinho-400)' }
      : variant === 'ghost' ? { background: 'var(--card-2)', color: 'var(--fg1)' } : {})
    : {};
  return React.createElement('button', {
    onClick,
    onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false),
    style: { ...base, ...variants[variant], ...hoverStyle, ...style },
  }, icon && React.createElement(Icon, { name: icon, size: size === 'sm' ? 14 : 16 }), children);
};

const Badge = ({ children, tone = 'wine', glow }) => {
  const tones = {
    income: { background: 'rgba(34,197,94,0.12)', color: 'var(--receita)' },
    expense: { background: 'rgba(220,76,100,0.12)', color: 'var(--despesa)' },
    gold: { background: 'rgba(205,170,94,0.16)', color: 'var(--dourado-suave)' },
    wine: { background: 'rgba(190,75,107,0.18)', color: 'var(--vinho-200)' },
    warn: { background: 'rgba(212,175,55,0.12)', color: 'var(--aviso)' },
  };
  return React.createElement('span', {
    style: {
      display: 'inline-flex', alignItems: 'center', gap: 5, padding: '4px 10px',
      borderRadius: 'var(--r-pill)', fontSize: 12, fontWeight: 600, ...tones[tone],
      boxShadow: glow ? 'var(--shadow-glow-gold)' : 'none',
    },
  }, children);
};

const Value = ({ amount, type, size = 22, prefixSign }) => {
  const color = type === 'income' ? 'var(--receita)' : type === 'expense' ? 'var(--despesa)' : 'var(--fg1)';
  const txt = prefixSign ? signed(amount) : (type === 'expense' ? '− ' : type === 'income' ? '+ ' : '') + fmt(amount);
  return React.createElement('span', {
    style: { fontFamily: 'var(--font-mono)', fontWeight: 500, fontVariantNumeric: 'tabular-nums', fontSize: size, color, letterSpacing: '-0.01em', whiteSpace: 'nowrap' },
  }, txt);
};

// ---------- Mock data ----------
const NAV = [
  { key: 'resumo', label: 'Resumo', icon: 'layout-dashboard' },
  { key: 'transacoes', label: 'Transações', icon: 'arrow-left-right' },
  { key: 'planejamento', label: 'Planejamento', icon: 'wallet' },
  { key: 'metas', label: 'Metas', icon: 'target' },
  { key: 'relatorios', label: 'Relatórios', icon: 'bar-chart-3' },
  { key: 'categorias', label: 'Categorias', icon: 'tags' },
  { key: 'contas', label: 'Contas', icon: 'credit-card' },
  { key: 'investimentos', label: 'Investimentos', icon: 'trending-up' },
];

const CATEGORIES = [
  { name: 'Moradia', pct: 35, color: '#7B1E3A' },
  { name: 'Alimentação', pct: 25, color: '#BE4B6B' },
  { name: 'Transporte', pct: 15, color: '#D98AA0' },
  { name: 'Lazer', pct: 10, color: '#CDAA5E' },
  { name: 'Outros', pct: 15, color: '#8A6F76' },
];

const CASHFLOW = [
  { m: 'Jan', rec: 14, desp: 9 },
  { m: 'Fev', rec: 16, desp: 11 },
  { m: 'Mar', rec: 15, desp: 13 },
  { m: 'Abr', rec: 17, desp: 8 },
  { m: 'Mai', rec: 18.75, desp: 6.41 },
];

const TRANSACTIONS = [
  { id: 1, name: 'Supermercado Extra', cat: 'Alimentação', date: '24 Mai', amount: -234.5, icon: 'shopping-cart', tag: 'necessário' },
  { id: 2, name: 'Salário', cat: 'Receita', date: '24 Mai', amount: 4750, icon: 'briefcase', tag: null },
  { id: 3, name: 'Uber', cat: 'Transporte', date: '23 Mai', amount: -35.9, icon: 'car', tag: 'necessário' },
  { id: 4, name: 'Netflix', cat: 'Assinaturas', date: '22 Mai', amount: -55.9, icon: 'tv', tag: 'conforto' },
  { id: 5, name: 'iFood', cat: 'Alimentação', date: '21 Mai', amount: -68.4, icon: 'utensils', tag: 'impulso' },
  { id: 6, name: 'Posto Shell', cat: 'Transporte', date: '20 Mai', amount: -180.0, icon: 'fuel', tag: 'necessário' },
];

const ACCOUNTS = [
  { name: 'Conta Principal', balance: 8750, icon: 'landmark', color: '#7B1E3A' },
  { name: 'Cartão de Crédito', balance: -1250, icon: 'credit-card', color: '#BE4B6B' },
  { name: 'Investimentos', balance: 4840, icon: 'trending-up', color: '#CDAA5E' },
];

Object.assign(window, {
  Icon, useLucide, fmt, signed, Card, Button, Badge, Value,
  NAV, CATEGORIES, CASHFLOW, TRANSACTIONS, ACCOUNTS,
});
