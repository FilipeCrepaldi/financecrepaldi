# Finance Mirror — UI Kit

High-fidelity, interactive recreation of the **Finance Mirror** web app, rebranded to the wine/bege/gold identity from the brand manual + mockups. This is a cosmetic recreation for prototyping — not production code.

## Run
Open `index.html`. It boots on the **login screen** → click **Entrar** (or "Esqueceu sua senha?") to enter the app.

## Interactions
- **Sidebar** navigation — *Resumo* (Dashboard) and *Transações* are fully built; other routes show an honest "Em breve" placeholder (those surfaces exist in the product but aren't reproduced here).
- **Lançar** button or **`K`** shortcut opens the **Quick Entry** modal. Type natural language (`32 ifood almoço`) — it parses amount + merchant + category live and adds the transaction to the list.
- **Transações** page: search + type filters (Todos / Receitas / Despesas).
- **Month selector** dropdown in the topbar.

## Files
| File | What |
|---|---|
| `index.html` | Entry point — React 18 + Babel + Lucide; loads all modules |
| `components.jsx` | Primitives (`Card`, `Button`, `Badge`, `Value`, `Icon`) + mock data (NAV, CATEGORIES, CASHFLOW, TRANSACTIONS, ACCOUNTS) |
| `charts.jsx` | `Sparkline`, `BarChart`, `Donut` — soft, low-noise SVG data viz |
| `Sidebar.jsx` | Desktop nav shell with logo + active/hover states |
| `Topbar.jsx` | Greeting, month selector, Lançar, notification bell |
| `LoginScreen.jsx` | Auth screen matching `mockup_login` |
| `Dashboard.jsx` | Resumo: stat cards, cash-flow bars, category donut, recent transactions, accounts |
| `Transactions.jsx` | Transação list + filter chips + search |
| `QuickEntry.jsx` | Natural-language entry modal with live preview + parser |
| `App.jsx` | Shell: auth gate, routing, quick-entry state, `K` shortcut |

## Notes
- All components export to `window` (Babel script scope isolation) — see the bottom of each file.
- Financial values render in JetBrains Mono with tabular figures; everything else in Inter.
- Icons are Lucide (CDN), thin outline — the same set the real codebase uses.
- Built faithful to `assets/mockup_dark.png` / `mockup_light.png` / `mockup_login.png`. Light mode tokens exist in `colors_and_type.css` (`data-theme="light"`) but the kit ships in dark (the product's primary surface).
