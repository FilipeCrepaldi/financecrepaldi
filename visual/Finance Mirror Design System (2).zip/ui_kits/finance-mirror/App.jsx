// Finance Mirror UI Kit — App shell tying everything into an interactive click-through.

function Placeholder({ title }) {
  useLucide();
  return React.createElement('div', { style: { padding: 28 } },
    React.createElement('h1', { style: { fontSize: 24, fontWeight: 700, color: 'var(--fg1)', marginBottom: 18 } }, title),
    React.createElement(Card, { pad: 48, style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, textAlign: 'center' } },
      React.createElement('div', { style: { width: 52, height: 52, borderRadius: 14, background: 'rgba(123,30,58,0.18)', display: 'flex', alignItems: 'center', justifyContent: 'center' } },
        React.createElement(Icon, { name: 'sparkles', size: 22, color: 'var(--rosa-rubi)' })),
      React.createElement('div', { style: { fontSize: 16, fontWeight: 600, color: 'var(--fg1)' } }, 'Em breve'),
      React.createElement('p', { style: { fontSize: 13, color: 'var(--fg3)', maxWidth: 320, lineHeight: 1.5 } },
        'Esta superfície existe no produto mas não está reproduzida neste UI kit. Veja Resumo e Transações para os componentes implementados.')));
}

function App() {
  const [logged, setLogged] = React.useState(false);
  const [route, setRoute] = React.useState('resumo');
  const [quickOpen, setQuickOpen] = React.useState(false);
  const [transactions, setTransactions] = React.useState(TRANSACTIONS);

  // K = quick entry shortcut
  React.useEffect(() => {
    const h = (e) => {
      const tag = (e.target.tagName || '').toUpperCase();
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (e.metaKey || e.ctrlKey) return;
      if (logged && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); setQuickOpen(true); }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [logged]);

  React.useEffect(() => { if (window.lucide) window.lucide.createIcons(); });

  if (!logged) return React.createElement(LoginScreen, { onLogin: () => setLogged(true) });

  let page;
  if (route === 'resumo') page = React.createElement(Dashboard, { transactions });
  else if (route === 'transacoes') page = React.createElement(Transactions, { transactions });
  else page = React.createElement(Placeholder, { title: (NAV.find((n) => n.key === route) || { label: 'Configurações' }).label });

  return React.createElement('div', { style: { display: 'flex', height: '100vh', overflow: 'hidden', background: 'var(--bg)' } },
    React.createElement(Sidebar, { active: route, onNavigate: setRoute, onSignOut: () => { setLogged(false); setRoute('resumo'); } }),
    React.createElement('div', { style: { flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, overflow: 'hidden' } },
      React.createElement(Topbar, { onQuickEntry: () => setQuickOpen(true) }),
      React.createElement('main', { style: { flex: 1, overflowY: 'auto' } }, page)),
    quickOpen && React.createElement(QuickEntry, {
      onClose: () => setQuickOpen(false),
      onAdd: (t) => setTransactions((prev) => [t, ...prev]),
    }));
}

ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(App));
