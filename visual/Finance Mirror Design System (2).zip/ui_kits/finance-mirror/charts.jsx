// Finance Mirror UI Kit — lightweight SVG chart primitives (data viz, soft & low-noise).

const Sparkline = ({ data, color, width = 110, height = 36 }) => {
  const max = Math.max(...data), min = Math.min(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - ((v - min) / range) * (height - 6) - 3;
    return [x, y];
  });
  const d = pts.map((p, i) => (i === 0 ? 'M' : 'L') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
  const area = d + ` L${width} ${height} L0 ${height} Z`;
  const gid = 'spark' + color.replace('#', '');
  return React.createElement('svg', { width, height, style: { display: 'block', overflow: 'visible' } },
    React.createElement('defs', null,
      React.createElement('linearGradient', { id: gid, x1: 0, y1: 0, x2: 0, y2: 1 },
        React.createElement('stop', { offset: '0%', stopColor: color, stopOpacity: 0.28 }),
        React.createElement('stop', { offset: '100%', stopColor: color, stopOpacity: 0 }))),
    React.createElement('path', { d: area, fill: `url(#${gid})` }),
    React.createElement('path', { d, fill: 'none', stroke: color, strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' }));
};

const BarChart = ({ data, height = 150 }) => {
  const max = Math.max(...data.flatMap((d) => [d.rec, d.desp]));
  return React.createElement('div', { style: { display: 'flex', alignItems: 'flex-end', gap: 18, height, paddingTop: 8 } },
    data.map((d) =>
      React.createElement('div', { key: d.m, style: { flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 } },
        React.createElement('div', { style: { display: 'flex', gap: 4, alignItems: 'flex-end', height: height - 24, width: '100%', justifyContent: 'center' } },
          React.createElement('div', { style: { width: 14, height: `${(d.rec / max) * 100}%`, background: 'var(--receita)', borderRadius: '4px 4px 0 0', opacity: 0.9 } }),
          React.createElement('div', { style: { width: 14, height: `${(d.desp / max) * 100}%`, background: 'var(--despesa)', borderRadius: '4px 4px 0 0', opacity: 0.9 } })),
        React.createElement('span', { style: { fontSize: 11, color: 'var(--fg3)' } }, d.m))));
};

const Donut = ({ data, size = 132, thickness = 20, centerLabel, centerSub }) => {
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  let offset = 0;
  return React.createElement('div', { style: { position: 'relative', width: size, height: size } },
    React.createElement('svg', { width: size, height: size, style: { transform: 'rotate(-90deg)' } },
      data.map((seg, i) => {
        const len = (seg.pct / 100) * c;
        const el = React.createElement('circle', {
          key: i, cx: size / 2, cy: size / 2, r, fill: 'none', stroke: seg.color,
          strokeWidth: thickness, strokeDasharray: `${len} ${c - len}`, strokeDashoffset: -offset,
        });
        offset += len;
        return el;
      })),
    centerLabel && React.createElement('div', {
      style: { position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' },
    },
      React.createElement('span', { style: { fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 24, color: 'var(--fg1)' } }, centerLabel),
      centerSub && React.createElement('span', { style: { fontSize: 10, color: 'var(--fg3)', marginTop: 2 } }, centerSub)));
};

Object.assign(window, { Sparkline, BarChart, Donut });
