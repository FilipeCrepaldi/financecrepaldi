// Finance Mirror UI Kit — Transactions page (Transações): filters + full list.

function Transactions({ transactions }) {
  useLucide();
  const [filter, setFilter] = React.useState('todos');
  const [query, setQuery] = React.useState('');
  const filtered = transactions.filter((t) => {
    const typeOk = filter === 'todos' || (filter === 'receita' ? t.amount >= 0 : t.amount < 0);
    const qOk = !query || t.name.toLowerCase().includes(query.toLowerCase());
    return typeOk && qOk;
  });
  const chip = (key, label) =>
    React.createElement('button', {
      key, onClick: () => setFilter(key),
      style: {
        padding: '7px 14px', borderRadius: 'var(--r-pill)', fontSize: 13, cursor: 'pointer', fontFamily: 'var(--font-sans)',
        border: '1px solid ' + (filter === key ? 'transparent' : 'var(--border)'),
        background: filter === key ? 'var(--vinho-profundo)' : 'transparent',
        color: filter === key ? '#fff' : 'var(--fg2)', fontWeight: filter === key ? 600 : 400,
      },
    }, label);

  return React.createElement('div', { style: { padding: 28, display: 'flex', flexDirection: 'column', gap: 18 } },
    React.createElement('div', null,
      React.createElement('h1', { style: { fontSize: 24, fontWeight: 700, color: 'var(--fg1)' } }, 'Transações'),
      React.createElement('p', { style: { fontSize: 14, color: 'var(--fg2)', marginTop: 2 } }, filtered.length + ' lançamentos em Maio de 2024')),
    // Filter bar
    React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' } },
      React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 9, background: 'var(--bg-2)', border: '1px solid var(--border)', borderRadius: 'var(--r-md)', padding: '9px 13px', flex: 1, minWidth: 220 } },
        React.createElement(Icon, { name: 'search', size: 16, color: 'var(--fg3)' }),
        React.createElement('input', {
          value: query, onChange: (e) => setQuery(e.target.value), placeholder: 'Buscar transação…',
          style: { background: 'transparent', border: 'none', outline: 'none', color: 'var(--fg1)', fontSize: 14, flex: 1, fontFamily: 'var(--font-sans)' },
        })),
      chip('todos', 'Todos'), chip('receita', 'Receitas'), chip('despesa', 'Despesas'),
      React.createElement(Button, { variant: 'ghost', size: 'sm', icon: 'sliders-horizontal' }, 'Filtros')),
    // List
    React.createElement(Card, { pad: 8 },
      filtered.map((t, i) =>
        React.createElement('div', {
          key: t.id,
          style: { display: 'flex', alignItems: 'center', gap: 14, padding: '12px 12px', borderBottom: i < filtered.length - 1 ? '1px solid var(--border-soft)' : 'none' },
        },
          React.createElement('div', { style: { width: 40, height: 40, borderRadius: 11, background: 'var(--bg-2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 } },
            React.createElement(Icon, { name: t.icon, size: 17, color: t.amount >= 0 ? 'var(--receita)' : 'var(--rosa-rubi)' })),
          React.createElement('div', { style: { flex: 1, minWidth: 0 } },
            React.createElement('div', { style: { fontSize: 14, color: 'var(--fg1)', fontWeight: 500 } }, t.name),
            React.createElement('div', { style: { fontSize: 12, color: 'var(--fg3)', display: 'flex', alignItems: 'center', gap: 8, marginTop: 2 } },
              React.createElement('span', null, t.cat),
              t.tag && React.createElement('span', { style: { padding: '1px 8px', borderRadius: 'var(--r-sm)', background: 'var(--card-2)', border: '1px solid var(--border)', color: 'var(--fg2)' } }, t.tag))),
          React.createElement('span', { style: { fontSize: 12, color: 'var(--fg3)', width: 60, textAlign: 'right' } }, t.date),
          React.createElement('div', { style: { width: 120, textAlign: 'right' } },
            React.createElement(Value, { amount: t.amount, type: t.amount >= 0 ? 'income' : 'expense', size: 14, prefixSign: true }))))));
}

Object.assign(window, { Transactions });
