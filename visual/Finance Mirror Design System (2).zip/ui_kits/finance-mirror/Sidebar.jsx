// Finance Mirror UI Kit — Sidebar (desktop nav shell, matches dark mockup).

function Sidebar({ active, onNavigate, onSignOut }) {
  useLucide();
  return React.createElement('aside', {
    style: {
      width: 232, flexShrink: 0, background: 'var(--bg-2)', borderRight: '1px solid var(--border)',
      display: 'flex', flexDirection: 'column', height: '100%',
    },
  },
    // Logo
    React.createElement('div', { style: { padding: '20px 18px', display: 'flex', alignItems: 'center', gap: 10 } },
      React.createElement('img', { src: '../../assets/logo.png', alt: '', style: { width: 34, height: 34, borderRadius: 8, objectFit: 'cover' } }),
      React.createElement('span', { style: { fontWeight: 700, fontSize: 16, color: 'var(--fg1)', letterSpacing: '-0.01em' } },
        'finance', React.createElement('span', { style: { color: 'var(--rosa-rubi)' } }, '-'), 'mirror')),
    // Nav
    React.createElement('nav', { style: { flex: 1, padding: '8px 12px', display: 'flex', flexDirection: 'column', gap: 3, overflowY: 'auto' } },
      NAV.map((item) => {
        const isActive = active === item.key;
        return React.createElement('button', {
          key: item.key, onClick: () => onNavigate(item.key),
          style: {
            display: 'flex', alignItems: 'center', gap: 12, padding: '10px 13px', borderRadius: 'var(--r-md)',
            fontSize: 14, fontFamily: 'var(--font-sans)', border: 'none', cursor: 'pointer', width: '100%', textAlign: 'left',
            background: isActive ? 'rgba(123,30,58,0.22)' : 'transparent',
            color: isActive ? 'var(--rosa-rubi)' : 'var(--fg2)',
            fontWeight: isActive ? 600 : 400,
            transition: 'all 150ms cubic-bezier(0.16,1,0.3,1)',
          },
          onMouseEnter: (e) => { if (!isActive) { e.currentTarget.style.background = 'var(--card-2)'; e.currentTarget.style.color = 'var(--fg1)'; } },
          onMouseLeave: (e) => { if (!isActive) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--fg2)'; } },
        },
          React.createElement(Icon, { name: item.icon, size: 17 }),
          React.createElement('span', null, item.label));
      })),
    // Footer
    React.createElement('div', { style: { padding: 12, borderTop: '1px solid var(--border)' } },
      React.createElement('button', {
        onClick: () => onNavigate('config'),
        style: { display: 'flex', alignItems: 'center', gap: 12, padding: '10px 13px', borderRadius: 'var(--r-md)', fontSize: 14, color: 'var(--fg2)', background: 'none', border: 'none', cursor: 'pointer', width: '100%', fontFamily: 'var(--font-sans)' },
      }, React.createElement(Icon, { name: 'settings', size: 17 }), 'Configurações'),
      React.createElement('button', {
        onClick: onSignOut,
        style: { display: 'flex', alignItems: 'center', gap: 12, padding: '10px 13px', borderRadius: 'var(--r-md)', fontSize: 14, color: 'var(--fg2)', background: 'none', border: 'none', cursor: 'pointer', width: '100%', fontFamily: 'var(--font-sans)' },
      }, React.createElement(Icon, { name: 'log-out', size: 17 }), 'Sair')));
}

Object.assign(window, { Sidebar });
